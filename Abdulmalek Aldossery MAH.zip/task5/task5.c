#include <stdio.h>

int main() {
	int E,A,I,O,U, others;
	E = A = I = O = U = others = 0;
	int n; 
	char character;
	printf("Enter the value of n: ");
	scanf("%d", &n);
	for(int i = 0; i < n; i++){
	    printf("Enter a character: ");
	    getchar();
	    scanf("%c", &character);
	    if(character == 'e' || character == 'E'){
	        E++;
	    } else if(character == 'a' || character == 'A'){
	        A++;
	    } else if(character == 'i' || character == 'I'){
	        I++;
	    } else if(character == 'o' || character == 'O'){
	        O++;
	    } else if(character == 'u' || character == 'U'){
	        U++;
	    } else {
	        others++;
	    }
	}
	
	printf("\tFrequency of a = %d\n",A);
	printf("\tFrequency of e = %d\n",E);
	printf("\tFrequency of i = %d\n",I);
	printf("\tFrequency of o = %d\n",O);
	printf("\tFrequency of u = %d\n",U);
	printf("\tFrequency of others = %d\n", others);
	return 0;
}
